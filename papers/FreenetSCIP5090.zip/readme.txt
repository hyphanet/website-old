Freenet Self Containing Installer Package

Readme


1)unzip package
2)extract files to folder
3)run 'freenet-webinstall.exe'
4)follow the install-wizard
5)run the node (a small icon of a rabbit will appear in the tray; blue when succesfull)



The Freenet SCIP is a zipfile of the needed files, but does not necessarily contain the most recent jar or seednodes.ref.
The number in the SCIP-name is indicative of the build; e.g. FreenetSCIP5069.zip contains (stable) build 5069.


For more information, go to http://freenetproject.org/ or http://www.freenethelp.org
For non-coding matters, you can also contact newsbyte@freenetproject.org