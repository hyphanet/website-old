#!/bin/sh

kill `cat freenet.pid`

