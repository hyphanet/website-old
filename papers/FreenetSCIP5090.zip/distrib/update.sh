#!/bin/bash
wget http://freenetproject.org/snapshots/freenet-latest.jar -O freenet.jar
wget http://freenetproject.org/snapshots/seednodes.ref -O seednodes.ref
touch -d "1/1/1970" seednodes.ref
# so we don't reseed unless necessary
